// Import library for sql connection (connectorJ)
import java.sql.*;
import java.util.ArrayList;
import java.util.Random;

public class k_means {
	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost/";
	// Database credentials
	static final String USER = "root";
	static final String PASS = "admin"; // insert the password to SQL server
			
	// Database connections/statements
	public static Connection conn = null;
	public static Statement stmt = null;
	public static String sql = "";
	public static ResultSet res = null;
	
	//Creation of the list of all the points
	public static int d; //number of points
	public static time_point[] point_list = new time_point[0]; //datas for the training
	public static time_point[] test_list = new time_point[0]; //datas for the test
	
	//Pre-definition of all the points
	public static double[][] point_value = new double[9][2];
	public static ArrayList<String> bus_name = new ArrayList<String>(9);
	
	//Cluster creation
	public static time_point[] clusters = new time_point[4];  //final cluster after training
	public static double[][][] min_max = new double[9][2][2];
	
	//The different threshold for the solvers
	public static double threshold_cluster_solving = 1/1000;
	public static double threshold_cluster_solved = 1/1000;
	
	//K-NN value chosen
	public static int k_nn = 5;
	
	//Table names
	public static String measures = "measurements";
	public static String test = "analog_values";
	
	
	// Functions
	public static void main(String[] args) {
		//Definition of all the bus
		bus_name.add("CLAR"); bus_name.add("AMHE"); bus_name.add("WINL"); 
		bus_name.add("BOWM"); bus_name.add("TROY"); bus_name.add("MAPL");
		bus_name.add("GRAN"); bus_name.add("WAUT"); bus_name.add("CROSS");

		
		try {
			// Connection to the database
			// Register JDBC driver
			Class.forName(JDBC_DRIVER).newInstance();
			// Connect to the created database STUDENTS and create table REGISTRATION
			conn = DriverManager.getConnection(DB_URL + "ASSIGN2", USER, PASS);
			
			// k-means clustering
			point_list = fill_list_point(measures);
			
			//Initialization of the cluster
			time_point[] init_cluster = initialize_cluster2(point_list);
			
			//Solving the previously initialized cluster
			time_point[] solved_clust = solving_cluster(init_cluster);
			//Saved it
			clusters = solved_clust;
			
			int count = 0;
			//Repeat the process severals time so that we have the cluster with the lowest J
			while(count < 5) {
				init_cluster = initialize_cluster2(point_list);
				solved_clust = solving_cluster(init_cluster);
				if(J_computation(clusters, point_list) - J_computation(solved_clust, point_list) > threshold_cluster_solved) {
					clusters = solved_clust;
					count = 0;
				} else {
					count += 1;
				}
			}
			print_cluster(clusters);
			
			String[] labels = label_cluster(clusters);
			
			// K-NN part
			test_list = fill_list_point(test);
			
			int corresp_clust = 0;
			for(int i=0; i<test_list.length; i++) {
				corresp_clust = corresponding_cluster(test_list[i], clusters, point_list,  k_nn);
				int true_time = i + 1;
				System.out.println("The point at t = "+ true_time +"s corresponds to a "+ labels[corresp_clust]);
			}
			
		}catch(SQLException se){se.printStackTrace(); //JDBC errors
		}catch(Exception e){e.printStackTrace();} //forName class error
	}
	
	//Function extracting the datas from the database
	public static time_point[] fill_list_point(String table_name) {
		System.out.println("Starting the extraction of the datas...");
		time_point[] extracted_data = new time_point[0];
		
		try {
			//Initialization 
			stmt = conn.createStatement();
			sql = "SELECT COUNT(*) FROM "+table_name+" WHERE assign2."+table_name+".name='CLAR_VOLT'";
			res = stmt.executeQuery(sql);
			while (res.next()) {
				d = Integer.parseInt(res.getString("COUNT(*)"));
				System.out.println("Number of points to extract : " + d);
			}
			extracted_data = new time_point[d];
			
			
			for(int i=0; i<d; i++) {
				for(int j=0; j<bus_name.size(); j++) {
					String str = bus_name.get(j);
					sql = "SELECT * FROM "+table_name+" WHERE assign2."+table_name+".name='" + str + "_VOLT' AND assign2."+table_name+".time =" + String.valueOf(i);
					res = stmt.executeQuery(sql);
					while (res.next()) {
						point_value[j][0] = Double.parseDouble(res.getString("value"));
						//System.out.println(str + "_VOLT :" + point_value[j][0]);
					}
					
					sql = "SELECT * FROM "+table_name+" WHERE assign2."+table_name+".name='" + str + "_ANG' AND assign2."+table_name+".time =" + String.valueOf(i);
					res = stmt.executeQuery(sql);
					while (res.next()) {
						point_value[j][1] = Double.parseDouble(res.getString("value"));
						//System.out.println(str + "_ANG :" + point_value[j][1]);
					}
				}
				extracted_data[i] = new time_point(i+1, point_value);
				System.out.println("Point " + i + " extracted ");
			}
			
			System.out.println("Data extracted from the database"); System.out.println("");
			
		}catch(SQLException se){se.printStackTrace(); //JDBC errors
		}catch(Exception e){e.printStackTrace();} //forName class error
		
		return extracted_data;
	}
	
	//k-means part
	//Useless function previously used for the initialization vector
	public static void find_minmax() {
		System.out.println("Looking for Minimum and Maximum of each variables");
		
		try {
			for(int j=0; j<bus_name.size(); j++) {
				String str = bus_name.get(j);
				//Initialization 
				stmt = conn.createStatement();
				sql = "SELECT MAX(assign2.measurements.value), MIN(assign2.measurements.value) "
						+ "FROM assign2.measurements "
						+ "WHERE assign2.measurements.name='"+str+"_VOLT'";
				res = stmt.executeQuery(sql);
				double maxi = 0; double mini = 0;
				while (res.next()) {
					maxi = Double.parseDouble(res.getString("MAX(assign2.measurements.value)"));
					mini = Double.parseDouble(res.getString("MIN(assign2.measurements.value)"));
				}
				min_max[j][0][0] = mini; min_max[j][0][1] = maxi; 
				
				stmt = conn.createStatement();
				sql = "SELECT MAX(assign2.measurements.value), MIN(assign2.measurements.value) "
						+ "FROM assign2.measurements "
						+ "WHERE assign2.measurements.name='"+str+"_ANG'";
				res = stmt.executeQuery(sql);
				while (res.next()) {
					maxi = Double.parseDouble(res.getString("MAX(assign2.measurements.value)"));
					mini = Double.parseDouble(res.getString("MIN(assign2.measurements.value)"));
				}
				min_max[j][1][0] = mini; min_max[j][1][1] = maxi; 
			}
			System.out.println("Minimums and Maximums extracted"); System.out.println("");
			
		}catch(SQLException se){se.printStackTrace(); //JDBC errors
		}catch(Exception e){e.printStackTrace();} //forName class error
	}
	
	//First attempt of an initialization of the cluster vector -> didn't work
	public static time_point[] initialize_cluster1() {
		time_point[] init_cluster = new time_point[4];
		for(int i=0; i<4; i++) {
			for(int j=0; j<bus_name.size(); j++) {
				point_value[j][0] = random_double(min_max[j][0][0], min_max[j][0][1]);
				point_value[j][1] = random_double(min_max[j][1][0], min_max[j][1][1]);
			}
			init_cluster[i] = new time_point(0, point_value);
		}		
		return init_cluster;
	}
	
	//Second attempt of the cluster initialization as a non-completely random initialization : see the video for explanations
	public static time_point[] initialize_cluster2(time_point[] p_list) {
		time_point[] initi_cluster = new time_point[4];
		int maximum = p_list.length;
		for(int i=0; i<4; i++) {
			int index = random_integer(maximum);
			initi_cluster[i] = p_list[index];
		}		
		//System.out.println("Cluster initialized");
		return initi_cluster;
	}
	
	//Function used to solve the initialized cluster entered as an input
	public static time_point[] solving_cluster(time_point[] clust) {
		time_point[] new_cluster = clust;
		time_point[] old_cluster = clust;
		double dist = 1;
		
		//The cluster is solved when the distance between two consecutive iteration
		//of it are approximately the same to a threshold acceptance
		while(dist > threshold_cluster_solving) {
			old_cluster = new_cluster;
			new_cluster = initialize_newcluster();
			
			//For each point of the training dataset, we find the closer cluster of the previously computed one
			for(int j = 0; j<point_list.length; j++) {
				int ind = find_closer_cluster(point_list[j], old_cluster);
				//Then we add all the values for each parameter of the new designed cluster
				new_cluster[ind].update_plus(point_list[j]);
			}
			
			for(int i=0; i<4; i++) {
				//Then we divide by the total amount of points that has been found close to 
				//this cluster : be aware that in this case, the time parameter of the time_point
				//object is seen as the number of point that this cluster was the closest of
				new_cluster[i].update_average();
			}	
			
			//Finally, we update the distance between the new cluster and the previous one
			dist = distance_allcluster(new_cluster, old_cluster);
		}
		return old_cluster;		
	}
	
	// Function that returns the index of the closest cluster of a specific point p
	public static int find_closer_cluster(time_point p, time_point[] cluster) {
		int clos = 0;
		double dist = cluster[clos].distance(p);
		for(int i=1; i<4; i++) {
			if(cluster[i].distance(p)<dist) { 
				clos = i;
				dist = cluster[clos].distance(p);
			}
		}
		return clos;
	}
	
	//Initialization of a zero value cluster in order to compute the average value of all the closest points 
	//of the previous cluster designed
	public static time_point[] initialize_newcluster() {
		time_point[] zero_cluster = new time_point[4];
		for(int j=0; j<9; j++) {
			point_value[j][0] = 0;
			point_value[j][1] = 0;
		}
		for(int j=0; j<4; j++) {
			zero_cluster[j] = new time_point(0, point_value);
		}
		return zero_cluster;
	}
	
	//Distance function of two cluster defined as the sum of the distance of each point of the cluster two by two
	public static double distance_allcluster(time_point[] clust1, time_point[] clust2) {
		double sum = clust1[0].distance(clust2[0]);
		sum += clust1[1].distance(clust2[1]);
		sum += clust1[2].distance(clust2[2]);
		sum += clust1[3].distance(clust2[3]);
		return sum;
	}
	
	//Computation of the J value for a specific set of point and a specific set of cluster
	public static double J_computation(time_point[] clust, time_point[] p_list) {
		double J = 0;
		for(int j=0; j<p_list.length; j++) {
			int ind = find_closer_cluster(p_list[j], clust);
			J += clust[ind].distance(p_list[j]);
		}
		return J;
	}
	
	//Function used to print as an output the clusters
	public static void print_cluster(time_point[] cluster) {
		for(int i=0; i<cluster.length; i++) {
			int j = i+1;
			System.out.println("Cluster N�" + j + " :");
			print_point(cluster[i]);
			System.out.println("");
		}
	}
	
	//Function used to print a point 
	public static void print_point(time_point p) {
		try {
			System.out.println("AMHE_ANG = " + p.get_AMHE_A());
			System.out.println("AMHE_VOLT = " + p.get_AMHE_V());
			System.out.println("BOWM_ANG = " + p.get_BOWM_A());
			System.out.println("BOWM_VOLT = " + p.get_BOWM_V());
			System.out.println("CLAR_ANG = " + p.get_CLAR_A());
			System.out.println("CLAR_VOLT = " + p.get_CLAR_V());
			System.out.println("CROSS_ANG = " + p.get_CROSS_A());
			System.out.println("CROSS_VOLT = " + p.get_CROSS_V());
			System.out.println("GRAN_ANG = " + p.get_GRAN_A());
			System.out.println("GRAN_VOLT = " + p.get_GRAN_V());
			System.out.println("MAPL_ANG = " + p.get_MAPL_A());
			System.out.println("MAPL_VOLT = " + p.get_MAPL_V());
			System.out.println("TROY_ANG = " + p.get_TROY_A());
			System.out.println("TROY_VOLT = " + p.get_TROY_V());
			System.out.println("WAUT_ANG = " + p.get_WAUT_A());
			System.out.println("WAUT_VOLT = " + p.get_WAUT_V());
			System.out.println("WINL_ANG = " + p.get_WINL_A());
			System.out.println("WINL_VOLT = " + p.get_WINL_V());
		}catch(Exception e) {}
	}
	
	
	//K-NN Part
	//Function that output the index of the corresponding cluster of a specific point extracted from the test set
	public static int corresponding_cluster(time_point p, time_point[] clust, time_point[] p_list, int k) {
		int clust_index = 0;
		int ind = 0;
		
		//First, we extract the k closest points to the specific point p
		time_point[] clos_points = find_closer_points(p, p_list, k);

		//Then we count within those points how many of them are close to which cluster
		int a1 = 0; int a2 = 0; int a3 = 0; int a4 = 0;
		for(int i=0; i<clos_points.length; i++) {
			ind = find_closer_cluster(clos_points[i], clust);
			if(ind == 0) {a1++;}
			if(ind == 1) {a2++;}
			if(ind == 2) {a3++;}
			if(ind == 3) {a4++;}
		}
		
		//Finally, we found the cluster with the highest amount of point close to it
		int maximum = max(max(a1,a2),max(a3,a4));
		if(maximum == a1) {clust_index = 0;}
		else if(maximum == a2) {clust_index = 1;}
		else if(maximum == a3) {clust_index = 2;}
		else {clust_index = 3;}
		
		return clust_index;
	}
	
	//Function that output the list of the k closest points of a specific point p (extracted from the test set)
	//regarding a list of point (training set)
	public static time_point[] find_closer_points(time_point p, time_point[] p_list, int k) {
		time_point[] closest_points = new time_point[k];
		int count_up = 0;
		time_point[] po_list = p_list.clone();
		while(count_up < k) {
			int ind = find_closest_point(p, po_list);
			closest_points[count_up] = po_list[ind];
			po_list = remove_elements(po_list, ind);
			count_up++;
		}		
		return closest_points;
	}
	
	//Find the index of the closest point of p in a list of points
	public static int find_closest_point(time_point p, time_point[] list) {
		int ind = 0;
		for(int i=0; i<list.length; i++) {
			if(p.distance(list[i])<p.distance(list[ind])) {
				ind = i;
			}
		}
		return ind;
	}
	
	//Remove the elements of index ind from a list of points
	public static time_point[] remove_elements(time_point[] old_list, int ind) {
		int dim = old_list.length;
		time_point[] new_list = new time_point[dim-1];
		int new_ind = 0; int old_ind = 0;
		while (old_ind < dim) {
			if(old_ind==ind) {
				old_ind++;
			} else {
				new_list[new_ind] = old_list[old_ind];
				new_ind++;
				old_ind++;
			}
		}
		return new_list;
	}
	
	
	//Extra useful function for the program
	public static double random_double(double minimum, double maximum) {
		double nbr = (Math.random() * ((maximum - minimum) + 1)) + minimum;
		return nbr;
	}
	
	public static Integer random_integer(int maximum) {
		Random rand = new Random();
		int nbr = rand.nextInt(maximum + 1);
		return nbr;
	}
	
	public static int max(int nb1, int nb2) {
		int m = nb1;
		if(nb1<nb2) {
			m = nb2;
		}
		return m;
	}
	
	public static double abs(double a) {
		if (a>0) {return a;}
		return -a;
	}
	
	// Labelling of the clusters
	public static String[] label_cluster(time_point[] clust) {
		String[] labeled_clust = new String[4];
		int ind1 = 0; int ind2 = 0; int ind3 = 0; int ind4 = 0;
		for(int k=1; k<4; k++) {
			if(low_rate_count(clust[ind1])<low_rate_count(clust[k])) {
				ind1 = k;
			}
		}
		for(int k=1; k<4; k++) {
			if(k!=ind1) {
				if(line_shut_down(clust[ind2])<line_shut_down(clust[k])) {
					ind2 = k;
				}
			}
		}
		for(int k=1; k<4; k++) {
			if((k!=ind1) && (k!=ind2)) {
				if(generator_shut_down(clust[ind3])<generator_shut_down(clust[k])) {
					ind2 = k;
				}
			}
		}
		ind4 = 3+2+1 - ind1 - ind2 - ind3;
		
		labeled_clust[ind1] = "Low load rate during night";
		labeled_clust[ind2] = "Disconnection of a line for maintenance";
		labeled_clust[ind3] = "Shut down of generator for maintenance";
		labeled_clust[ind4] = "High load rate during peak hours";
		return labeled_clust;
	}
	
	//Low load rate
	public static int low_rate_count(time_point cluster) {
		int count = 0;
		if(cluster.get_AMHE_A() > 0) {count++;}
		if(cluster.get_BOWM_A() > 0) {count++;}
		if(cluster.get_CLAR_A() > 0) {count++;}
		if(cluster.get_CROSS_A() > 0) {count++;}
		if(cluster.get_GRAN_A() > 0) {count++;}
		if(cluster.get_MAPL_A() > 0) {count++;}
		if(cluster.get_TROY_A() > 0) {count++;}
		if(cluster.get_WAUT_A() > 0) {count++;}
		if(cluster.get_WINL_A() > 0) {count++;}			
		return count;
	}
		
	//Low load rate
	public static int line_shut_down(time_point cluster) {
		int count = 0;
		if(cluster.get_AMHE_A() < 0) {count++;}
		if(cluster.get_BOWM_A() < 0) {count++;}
		if(cluster.get_CLAR_A() < 0) {count++;}
		if(cluster.get_CROSS_A() < 0) {count++;}
		if(cluster.get_GRAN_A() < 0) {count++;}
		if(cluster.get_MAPL_A() < 0) {count++;}
		if(cluster.get_TROY_A() < 0) {count++;}
		if(cluster.get_WAUT_A() < 0) {count++;}
		if(cluster.get_WINL_A() < 0) {count++;}
		if(abs(cluster.get_CLAR_V() - cluster.get_BOWM_V()) < 0.01) {count++;}
		if(abs(cluster.get_TROY_V() - cluster.get_BOWM_V()) < 0.01) {count++;}
		if(abs(cluster.get_CROSS_V() - cluster.get_BOWM_V()) < 0.01) {count++;}
		if(abs(cluster.get_TROY_V() - cluster.get_MAPL_V()) < 0.01) {count++;}
		if(abs(cluster.get_CROSS_V() - cluster.get_WAUT_V()) < 0.01) {count++;}
		if(abs(cluster.get_MAPL_V() - cluster.get_WINL_V()) < 0.01) {count++;}
		if(abs(cluster.get_MAPL_V() - cluster.get_GRAN_V()) < 0.01) {count++;}
		if(abs(cluster.get_AMHE_V() - cluster.get_WAUT_V()) < 0.01) {count++;}
		if(abs(cluster.get_WAUT_V() - cluster.get_GRAN_V()) < 0.01) {count++;}
		return count;
	}

	//Generator Shut Down
	public static int generator_shut_down(time_point cluster) {
		int count = 0;
		if(abs(cluster.get_CLAR_A() - cluster.get_BOWM_A()) < 1) {count++;}
		if(abs(cluster.get_MAPL_A() - cluster.get_WINL_A()) < 1) {count++;}
		if(abs(cluster.get_AMHE_A() - cluster.get_WAUT_A()) < 1) {count++;}
		return count;
	}
}
