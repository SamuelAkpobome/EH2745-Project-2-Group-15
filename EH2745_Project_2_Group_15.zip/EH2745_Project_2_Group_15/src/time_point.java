
public class time_point {
	//parameters of the time_point
	private int time;
	private double CLAR_VOLT; private double CLAR_ANG;
	private double AMHE_VOLT; private double AMHE_ANG;
	private double WINL_VOLT; private double WINL_ANG;
	private double BOWM_VOLT; private double BOWM_ANG;
	private double TROY_VOLT; private double TROY_ANG;
	private double MAPL_VOLT; private double MAPL_ANG;
	private double GRAN_VOLT; private double GRAN_ANG;
	private double WAUT_VOLT; private double WAUT_ANG;
	private double CROSS_VOLT; private double CROSS_ANG;
	
	// ponderation factor that help according the same 
	// imortance to both ang and volt values in the distance function
	public static double fact = 90/(1.1 - 0.7);

	//Initializaton
	public time_point(int t, double[][] point_value) {
		time = t;
		CLAR_VOLT = point_value[0][0]; CLAR_ANG = point_value[0][1];
		AMHE_VOLT = point_value[1][0]; AMHE_ANG = point_value[1][1];
		WINL_VOLT = point_value[2][0]; WINL_ANG = point_value[2][1];
		BOWM_VOLT = point_value[3][0]; BOWM_ANG = point_value[3][1];
		TROY_VOLT = point_value[4][0]; TROY_ANG = point_value[4][1];
		MAPL_VOLT = point_value[5][0]; MAPL_ANG = point_value[5][1];
		GRAN_VOLT = point_value[6][0]; GRAN_ANG = point_value[6][1];
		WAUT_VOLT = point_value[7][0]; WAUT_ANG = point_value[7][1];
		CROSS_VOLT = point_value[8][0]; CROSS_ANG = point_value[8][1];
	}
	
	//Update function for the variables
	public void updatePath(double[][] point_value) {
		CLAR_VOLT = point_value[0][0]; CLAR_ANG = point_value[0][1];
		AMHE_VOLT = point_value[1][0]; AMHE_ANG = point_value[1][1];
		WINL_VOLT = point_value[2][0]; WINL_ANG = point_value[2][1];
		BOWM_VOLT = point_value[3][0]; BOWM_ANG = point_value[3][1];
		TROY_VOLT = point_value[4][0]; TROY_ANG = point_value[4][1];
		MAPL_VOLT = point_value[5][0]; MAPL_ANG = point_value[5][1];
		GRAN_VOLT = point_value[6][0]; GRAN_ANG = point_value[6][1];
		WAUT_VOLT = point_value[7][0]; WAUT_ANG = point_value[7][1];
		CROSS_VOLT = point_value[8][0]; CROSS_ANG = point_value[8][1];
	}
	
	//Functions to get all of the different parameters (usefull to print the clusters)
	public double get_time() { return time;}
	
	public double get_CLAR_V() { return CLAR_VOLT;}
	public double get_CLAR_A() { return CLAR_ANG;}
	
	public double get_AMHE_V() { return AMHE_VOLT;}
	public double get_AMHE_A() { return AMHE_ANG;}
	
	public double get_WINL_V() { return WINL_VOLT;}
	public double get_WINL_A() { return WINL_ANG;}
	
	public double get_BOWM_V() { return BOWM_VOLT;}
	public double get_BOWM_A() { return BOWM_ANG;}
	
	public double get_TROY_V() { return TROY_VOLT;}
	public double get_TROY_A() { return TROY_ANG;}
	
	public double get_MAPL_V() { return MAPL_VOLT;}
	public double get_MAPL_A() { return MAPL_ANG;}
	
	public double get_GRAN_V() { return GRAN_VOLT;}
	public double get_GRAN_A() { return GRAN_ANG;}
	
	public double get_WAUT_V() { return WAUT_VOLT;}
	public double get_WAUT_A() { return WAUT_ANG;}
	
	public double get_CROSS_V() { return CROSS_VOLT;}
	public double get_CROSS_A() { return CROSS_ANG;}
	
	
	//Defining the distance function : the fact is used to ponderate the importance of each parameters
	public double distance(time_point b) {
		time_point a = this ;
		double sum = 0;
		try {
			sum += square(fact*(a.AMHE_VOLT - b.AMHE_VOLT)); sum += square(a.AMHE_ANG - b.AMHE_ANG);
			sum += square(fact*(a.BOWM_VOLT - b.BOWM_VOLT)); sum += square(a.BOWM_ANG - b.BOWM_ANG);
			sum += square(fact*(a.CLAR_VOLT - b.CLAR_VOLT)); sum += square(a.CLAR_ANG - b.CLAR_ANG);
			sum += square(fact*(a.CROSS_VOLT - b.CROSS_VOLT)); sum += square(a.CROSS_ANG - b.CROSS_ANG);
			sum += square(fact*(a.GRAN_VOLT - b.GRAN_VOLT)); sum += square(a.GRAN_ANG - b.GRAN_ANG);
			sum += square(fact*(a.MAPL_VOLT - b.MAPL_VOLT)); sum += square(a.MAPL_ANG - b.MAPL_ANG);
			sum += square(fact*(a.TROY_VOLT - b.TROY_VOLT)); sum += square(a.TROY_ANG - b.TROY_ANG);
			sum += square(fact*(a.WAUT_VOLT - b.WAUT_VOLT)); sum += square(a.WAUT_ANG - b.WAUT_ANG);
			sum += square(fact*(a.WINL_VOLT - b.WINL_VOLT)); sum += square(a.WINL_ANG - b.WINL_ANG);
		}catch(Exception e){}
		return Math.sqrt(sum);
	}
	
	public static double square(double a) {
		return a*a;
	}
	
	
	//Defining the plus function and divide function so that it 
	public void update_plus(time_point b) {
		time_point a = this;
	    try {
	    	time = a.time + 1;
		    AMHE_ANG = a.AMHE_ANG + b.AMHE_ANG; AMHE_VOLT = a.AMHE_VOLT + b.AMHE_VOLT;
		    BOWM_ANG = a.BOWM_ANG + b.BOWM_ANG; BOWM_VOLT = a.BOWM_VOLT + b.BOWM_VOLT;
		    CLAR_ANG = a.CLAR_ANG + b.CLAR_ANG; CLAR_VOLT = a.CLAR_VOLT + b.CLAR_VOLT;
		    CROSS_ANG = a.CROSS_ANG + b.CROSS_ANG; CROSS_VOLT = a.CROSS_VOLT + b.CROSS_VOLT;
		    GRAN_ANG = a.GRAN_ANG + b.GRAN_ANG; GRAN_VOLT = a.GRAN_VOLT + b.GRAN_VOLT;
		    MAPL_ANG = a.MAPL_ANG + b.MAPL_ANG; MAPL_VOLT = a.MAPL_VOLT + b.MAPL_VOLT;
		    TROY_ANG = a.TROY_ANG + b.TROY_ANG; TROY_VOLT = a.TROY_VOLT + b.TROY_VOLT;
		    WAUT_ANG = a.WAUT_ANG + b.WAUT_ANG; WAUT_VOLT = a.WAUT_VOLT + b.WAUT_VOLT;
		    WINL_ANG = a.WINL_ANG + b.WINL_ANG; WINL_VOLT = a.WINL_VOLT + b.WINL_VOLT;
	    }catch(Exception e) {}
	}
	
	public void update_average() {
		if(!(time==0)) {
			try {
				AMHE_ANG = AMHE_ANG/time; AMHE_VOLT = AMHE_VOLT/time;
				BOWM_ANG = BOWM_ANG/time; BOWM_VOLT = BOWM_VOLT/time;
				CLAR_ANG = CLAR_ANG/time; CLAR_VOLT = CLAR_VOLT/time;
				CROSS_ANG = CROSS_ANG/time; CROSS_VOLT = CROSS_VOLT/time;
				GRAN_ANG = GRAN_ANG/time; GRAN_VOLT = GRAN_VOLT/time;
				MAPL_ANG = MAPL_ANG/time; MAPL_VOLT = MAPL_VOLT/time;
				TROY_ANG = TROY_ANG/time; TROY_VOLT = TROY_VOLT/time;
				WAUT_ANG = WAUT_ANG/time; WAUT_VOLT = WAUT_VOLT/time;
				WINL_ANG = WINL_ANG/time; WINL_VOLT = WINL_VOLT/time;
			}catch(Exception e) {}
		}
	}
	
}
